import { Component, OnInit } from '@angular/core';
import { Validators, FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { loginDto } from './loginDto.model';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  empLoginForm: FormGroup;
  constructor(private fb: FormBuilder) { }


  ngOnInit() {

    this.empLoginForm = this.fb.group({      // initializes all formcontrolnames and give the control to empForm hence it carries all values as a single object.
      'id': new FormControl(''),
      'password': new FormControl('')
  })

  }

  loginEmp(emp:loginDto) {
    alert(emp.id);
  }

}
